#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node* next;
} Node;

Node* insertToBeginHasEmptyHead(Node* list, int n) {
    // your answer code
    return list;
}

Node* insertToEndHasEmptyHead(Node* list, int n) {
    // your answer code
    return list;
}

Node* insertToBeginNotEmptyHead(Node* list, int n) {
    // your answer code
    return list;
}

Node* insertToEndNotEmptyHead(Node* list, int n) {
    // your answer code
    return list;
}

void destoryListHasEmptyHead(Node* list) {
    // your answer code
    return ;
}

void destoryListNotEmptyHead(Node* list) {
    // your answer code
    return ;
}

void printListHasEmptyHead(Node* list);
void printListNotEmptyHead(Node* list);

void testHasEmptyHead() {
    // your test case
    Node* head = (Node*)malloc(sizeof(Node));
    head->data = -1;
    head = insertToBeginHasEmptyHead(head, 1);
    head = insertToBeginHasEmptyHead(head, 2);
    head = insertToBeginHasEmptyHead(head, 3);

    head = insertToEndHasEmptyHead(head, 10);
    head = insertToEndHasEmptyHead(head, 20);
    head = insertToEndHasEmptyHead(head, 30);

    printListHasEmptyHead(head);
    destoryListHasEmptyHead(head);
    printListHasEmptyHead(head);

    free(head);
    head = NULL;
}

void testNotEmptyHead() {
    // your test case
    Node* head = NULL;
    head = insertToBeginNotEmptyHead(head, 1);
    head = insertToBeginNotEmptyHead(head, 2);
    head = insertToBeginNotEmptyHead(head, 3);

    head = insertToEndNotEmptyHead(head, 10);
    head = insertToEndNotEmptyHead(head, 20);
    head = insertToEndNotEmptyHead(head, 30);

    printListNotEmptyHead(head);
    destoryListNotEmptyHead(head);
    printListNotEmptyHead(head);
}

int main(void) {
    testHasEmptyHead();
    testNotEmptyHead();

    return 0;
}

void printListHasEmptyHead(Node* list) {
    while (list->next != NULL) {
        printf("%d ", list->next->data);
        list = list->next;
    }
    printf("\n");
    return;
}

void printListNotEmptyHead(Node* list) {
    while (list != NULL) {
        printf("%d ", list->data);
        list = list->next;
    }
    printf("\n");
    return;
}