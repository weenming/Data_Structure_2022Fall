#include<iostream>
using namespace std;

typedef struct Node{
    int num;
    Node *next;
} Node;


Node* mySolution(Node* head){
    /*
        时间复杂度：
        空间复杂度： 
    */
   // your code
}

void test(){
    // 链表 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> 9 

    // Node h10 = {10, NULL};
    Node h9 = {9, NULL};
    Node h8 = {8, &h9};
    Node h7 = {7, &h8};
    Node h6 = {6, &h7};
    Node h5 = {5, &h6};
    Node h4 = {4, &h5};
    Node h3 = {3, &h4};
    Node h2 = {2, &h3};
    Node h1 = {1, &h2};

    // Node h1 = {1, NULL};
    

    Node* res = mySolution(&h1);
    while(res!=NULL){
        cout << res->num << " ";
        res = res->next;
    }
    cout << endl;

}


int main(){

    test();
    return 0;
}