#include<iostream>
#include<string>
using namespace std;



int mySolution(string a, string b){
    /*
        时间复杂度：
        空间复杂度: 
    */
   // your code

}


void test(){
    string a = "abcdefg";
    string b = "de";
    cout << mySolution(a, b) << endl;
}


int main(){
    test();
    return 0;
}