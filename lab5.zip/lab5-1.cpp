#include<iostream>
#include "myStack.hpp"
using namespace std;

int* mySolution(int arr[], int length){
    // 时间复杂度：
    // 空间复杂度： 

   
}

void test(){
    int arr[6] = {80,40,90,50,70,30};
    int* res = mySolution(arr, 6);
    for(int i=0;i<6;i++){
        cout << res[i] << "  ";
    }
    cout << endl;
}

int main(){

    test();
    return 0;
}