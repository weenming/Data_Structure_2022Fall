#include<iostream>
#include "myQueue.hpp"
using namespace std;



int* mySolution(int* arr, int length,int k){
    // 时间复杂度：
    // 空间复杂度：

}


void test(){
    int arr[8] = {1,2,3,4,5,6,7,8};
    int *res = mySolution(arr, 8, 3);
    for(int i = 0; i < 6; i++){
        cout << res[i] << "  ";
    } 
    cout << endl;

}

int main(){
    test();
    return 0;
}