#include<iostream>
using namespace std;

#define MAXSIZE 10000

template<typename T>
class Queue{
    private:
        T *arr;
        int front;
        int rear;
        int count;
        unsigned int maxSize;
    public:
        Queue();
        ~Queue();
        void push_front(T data);  // 入队
        void push_rear(T data); 
        T pop_front(); // 出队
        T pop_rear();

        T get_front(); // 取队头值
        T get_rear(); // 取出尾值

        bool is_empty(); // 判空
        bool is_full(); // 判满
};

