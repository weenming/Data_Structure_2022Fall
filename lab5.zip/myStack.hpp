#include<iostream>
using namespace std;


#define MAXSIZE 10000
template <typename T>
class Stack{
    private:
        unsigned int top;
        unsigned int maxSize;
        T *arr;
    
    public:
        Stack();
        ~Stack();


        void push(T data); // 推入元素
        T pop(); // 弹出栈顶元素
        T get_top(); // 获取栈顶元素
        unsigned int count();
        bool is_empty();
        bool is_full();

};

