#include<iostream>
#include"myStack.hpp"
#include"myQueue.hpp"
#include<vector>
#include<queue>
using namespace std;



typedef struct TreeNode
{
    int value;
    TreeNode *left;
    TreeNode *right;
    TreeNode(): value(0), left(nullptr), right(nullptr){}
    TreeNode(int x): value(x), left(nullptr), right(nullptr){}
    TreeNode(int x, TreeNode* left, TreeNode* right):value(x),left(left), right(right){}
}TreeNode;



vector<vector<int> > mySolution(TreeNode* root) {
    // 时间复杂度：
    // 空间复杂度：  
}



void test(){
    
    TreeNode* Node_1 = new TreeNode(1);
    TreeNode* Node_3 = new TreeNode(3);
    TreeNode* Node_4 = new TreeNode(4);
    TreeNode* Node_2 = new TreeNode(2,Node_3, Node_4);
    TreeNode* root = new TreeNode(0, Node_1, Node_2);

    vector<vector<int> > res = mySolution(root);
    for(auto i:res){
        for(auto c:i){
            cout << c << " ";
        }
    }
    cout << endl;
    return ;
    
}


int main(){
    test();
    return 0;
}