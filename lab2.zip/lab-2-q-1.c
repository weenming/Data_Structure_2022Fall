#include <stdio.h>

int rmDupFromSortArr(int *arr, int len) {
    // your answer code
    return 0;
}

void test1() {
    const int len = 9;
    int arr[len] = {1, 3, 5, 5, 5, 7, 9, 9, 11};

    int newLen = rmDupFromSortArr(arr, len);

    for (int i = 0; i < len; ++i) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    return;
}

int main() {
    test1();
    return 0;
}